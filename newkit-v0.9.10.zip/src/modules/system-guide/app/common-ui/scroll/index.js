angular.module('system-guide-common-ui-scroll', [])
  .controller("SystemGuideCommonScrollDemoCtrl", ["$scope", function ($scope) {

  }
]);
