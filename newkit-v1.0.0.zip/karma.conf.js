/**
 * Created by jh3r on 10/22/2015.
 */
module.exports = function(config){
  config.set({
    basePath: './',
    frameworks: ['mocha', 'chai'],
    files: [
      './dist/config/config.js',
      './dist/assets/js/assets.js',
      './dist/assets/js/newkit.js',

      './test/libs/angular-mocks.js',

      './dist/modules/app-common/app.js',

      './test/app-common/**/*.js'
    ],
    client: {
      mocha: {
        reporter: 'html',
        ui: 'bdd'
      }
    },
    browsers: ['Chrome'],
    exclude: [],
    port: 8889,
    colors: true,
    logLevel: config.LOG_INFO,
    singleRun: false
  })
};