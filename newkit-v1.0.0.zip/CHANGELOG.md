# Change Log
All notable changes to this project will be documented in this file.
## v1.0.1 (2015-x-x)

### Fixed

### Added
- 新增了ckeditor的中文支持

## v1.0.0 (2015-10-30)

### Fixed
- 修复菜单设置时，如果菜单项无子节点，点击添加子节点无效（UI无反应，数据上已经添加）的bug
- 修复新增根节点，无法选择ApplicationId，添加子节点，能选择ApplicationId的bug
- 修复了globalConfig中，get函数返回Key值的bug，应该返回Value值
- 修复菜单设置、全局搜索在Firefox下的显示问题
- 修复negAlert中，confirm方法自定义按钮时的属性覆盖问题（使用闭包解决）
- 修复了kendo弹窗的z-index值高于遮罩层的bug
- 修复刷新路由后，无法显示提示信息是bug
- 修复GlobalConfiguration，数据无法删除的bug

### Added
- 新增了消息提示（Message Tip）demo

### Changed
- 修改本地测试时，静态服务器的配置，禁用clicks，scroll，forms事件分发到所有测试浏览器
- 将about链接修改到toolbars

## v1.0.0 Beta (2015-10-17)

### Added
- 优化项目结构，将公共服务提取成module，更快的bug修复和功能更新；
- 引入了animate.css，可以很容易的实现CSS3动画
- 增加隐藏遮罩层的配置，在$http请求中，通过配置config中的hideLoading = true实现
- 创建CHANGELOG.md

### Changed
- angular升级到最新版本（1.4.7）；
- 升级font-awesome到4.4版本，图标用法从以前的icon-\*，变更为fa fa-*
- KendoUI升级到2015.Q3版本
- select2升级到ui-select，版本为0.13.1，具体用法请参考[https://github.com/angular-ui/ui-select](https://github.com/angular-ui/ui-select)
- /404、/401等系统路由变更为/system/404、/system/401
- angulartics-google-analytics 有变更，文件类有注释说明，关键字：newkit

### Remove
- 移除negColorPicker、negDatePicker、negTimePicker、negInputMask、negTree、negSpinner指令，请使用对应的Kendo控件替代
- 移除了ngBindHtmlUnsafe指令，可使用angular提供的ngBindHtml指令
- 移除指令negDropzone、validTip
- 移除指令modal，可使用negModal替代
- 服务messager设置为过期状态，不建议使用，请使用negAlert替代
- 移除服务progress