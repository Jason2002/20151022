/*!
 * Ace v1.3.3
 */
if ("undefined" == typeof jQuery) throw new Error("Ace's JavaScript requires jQuery");
! function (a, b) {
  var c = function (c, d) {
    function e(a) {
      a.preventDefault(), a.stopPropagation();
      var b = B.offset(),
        c = b[p],
        d = v ? a.pageY : a.pageX;
      d > c + H ? (H = d - c - G + J, H > I && (H = I)) : (H = d - c - J, 0 > H && (H = 0)), m.update_scroll()
    }

    function f(b) {
      b.preventDefault(), b.stopPropagation(), cb = bb = v ? b.pageY : b.pageX, R = !0, a("html").off("mousemove.ace_scroll").on("mousemove.ace_scroll", g), a(S).off("mouseup.ace_scroll").on("mouseup.ace_scroll", h), B.addClass("active"), T && m.$element.trigger("drag.start")
    }

    function g(a) {
      a.preventDefault(), a.stopPropagation(), cb = v ? a.pageY : a.pageX, cb - bb + H > I ? cb = bb + I - H : 0 > cb - bb + H && (cb = bb - H), H += cb - bb, bb = cb, 0 > H ? H = 0 : H > I && (H = I), m.update_scroll()
    }

    function h(b) {
      b.preventDefault(), b.stopPropagation(), R = !1, a("html").off(".ace_scroll"), a(S).off(".ace_scroll"), B.removeClass("active"), T && m.$element.trigger("drag.end"), x && X && !Z && j()
    }

    function i(a) {
      var b = +new Date;
      if ($ && b - eb > 1e3) {
        var c = A[u];
        _ != c && (_ = c, ab = !0, m.reset(!0)), eb = b
      }
      x && X && (null != db && (clearTimeout(db), db = null), B.addClass("not-idle"), Z || 1 != a || j())
    }

    function j() {
      null != db && (clearTimeout(db), db = null), db = setTimeout(function () {
        db = null, B.removeClass("not-idle")
      }, Y)
    }

    function k() {
      B.css("visibility", "hidden").addClass("scroll-hover"), O = v ? parseInt(B.outerWidth()) || 0 : parseInt(B.outerHeight()) || 0, B.css("visibility", "").removeClass("scroll-hover")
    }

    function l() {
      if (W !== !1) {
        var a = z.offset(),
          b = a.left,
          c = a.top;
        v ? N || (b += z.outerWidth() - O) : N || (c += z.outerHeight() - O), W === !0 ? B.css({
          top: parseInt(c),
          left: parseInt(b)
        }) : "left" === W ? B.css("left", parseInt(b)) : "top" === W && B.css("top", parseInt(c))
      }
    }
    var m = this,
      n = ace.helper.getAttrSettings(c, a.fn.ace_scroll.defaults),
      o = a.extend({}, a.fn.ace_scroll.defaults, d, n);
    this.size = 0, this.lock = !1, this.lock_anyway = !1, this.$element = a(c), this.element = c;
    var p, q, r, s, t, u, v = !0,
      w = !1,
      x = !1,
      y = !1,
      z = null,
      A = null,
      B = null,
      C = null,
      D = null,
      E = null,
      F = null,
      G = 0,
      H = 0,
      I = 0,
      J = 0,
      K = !0,
      L = !1,
      M = "",
      N = !1,
      O = 0,
      P = 1,
      Q = !1,
      R = !1,
      S = "onmouseup" in window ? window : "html",
      T = o.dragEvent || !1,
      U = d.scrollEvent || !1,
      V = o.detached || !1,
      W = o.updatePos || !1,
      X = o.hideOnIdle || !1,
      Y = o.hideDelay || 1500,
      Z = !1,
      $ = o.observeContent || !1,
      _ = 0,
      ab = !0;
    this.create = function (b) {
      if (!y) {
        b && (o = a.extend({}, a.fn.ace_scroll.defaults, b)), this.size = parseInt(this.$element.attr("data-size")) || o.size || 200, v = !o.horizontal, p = v ? "top" : "left", q = v ? "height" : "width", r = v ? "maxHeight" : "maxWidth", s = v ? "clientHeight" : "clientWidth", t = v ? "scrollTop" : "scrollLeft", u = v ? "scrollHeight" : "scrollWidth", this.$element.addClass("ace-scroll"), "static" == this.$element.css("position") ? (Q = this.element.style.position, this.element.style.position = "relative") : Q = !1;
        var c = null;
        V ? c = a('<div class="scroll-track scroll-detached"><div class="scroll-bar"></div></div>').appendTo("body") : (this.$element.wrapInner('<div class="scroll-content" />'), this.$element.prepend('<div class="scroll-track"><div class="scroll-bar"></div></div>')), z = this.$element, V || (z = this.$element.find(".scroll-content").eq(0)), v || z.wrapInner("<div />"), A = z.get(0), V ? (B = c, l()) : B = this.$element.find(".scroll-track").eq(0), C = B.find(".scroll-bar").eq(0), D = B.get(0), E = C.get(0), F = E.style, v || B.addClass("scroll-hz"), o.styleClass && (M = o.styleClass, B.addClass(M), N = !!M.match(/scroll\-left|scroll\-top/)), 0 == O && (B.show(), k()), B.hide(), B.on("mousedown", e), C.on("mousedown", f), z.on("scroll", function () {
          K && (H = parseInt(Math.round(this[t] * P)), F[p] = H + "px"), K = !1, U && this.$element.trigger("scroll", [A])
        }), o.mouseWheel && (this.lock = o.mouseWheelLock, this.lock_anyway = o.lockAnyway, this.$element.on(a.event.special.mousewheel ? "mousewheel.ace_scroll" : "mousewheel.ace_scroll DOMMouseScroll.ace_scroll", function (b) {
          if (!w) {
            if (i(!0), !x) return !m.lock_anyway;
            R && (R = !1, a("html").off(".ace_scroll"), a(S).off(".ace_scroll"), T && m.$element.trigger("drag.end")), b.deltaY = b.deltaY || 0;
            var c = b.deltaY > 0 || b.originalEvent.detail < 0 || b.originalEvent.wheelDelta > 0 ? 1 : -1,
              d = !1,
              e = A[s],
              f = A[t];
            m.lock || (d = -1 == c ? A[u] <= f + e : 0 == f), m.move_bar(!0);
            var g = parseInt(e / 8);
            return 80 > g && (g = 80), g > m.size && (g = m.size), g += 1, A[t] = f - c * g, d && !m.lock_anyway
          }
        }));
        var d = ace.vars.touch && "ace_drag" in a.event.special && o.touchDrag;
        if (d) {
          var g = "",
            h = d ? "ace_drag" : "swipe";
          this.$element.on(h + ".ace_scroll", function (a) {
            if (w) return void(a.retval.cancel = !0);
            if (i(!0), !x) return void(a.retval.cancel = this.lock_anyway);
            if (g = a.direction, v && ("up" == g || "down" == g) || !v && ("left" == g || "right" == g)) {
              var b = v ? a.dy : a.dx;
              0 != b && (Math.abs(b) > 20 && d && (b = 2 * b), m.move_bar(!0), A[t] = A[t] + b)
            }
          })
        }
        X && B.addClass("idle-hide"), $ && B.on("mouseenter.ace_scroll", function () {
          Z = !0, i(!1)
        }).on("mouseleave.ace_scroll", function () {
          Z = !1, 0 == R && j()
        }), this.$element.on("mouseenter.ace_scroll touchstart.ace_scroll", function () {
          ab = !0, $ ? i(!0) : o.hoverReset && m.reset(!0), B.addClass("scroll-hover")
        }).on("mouseleave.ace_scroll touchend.ace_scroll", function () {
          B.removeClass("scroll-hover")
        }), v || z.children(0).css(q, this.size), z.css(r, this.size), w = !1, y = !0
      }
    }, this.is_active = function () {
      return x
    }, this.is_enabled = function () {
      return !w
    }, this.move_bar = function (a) {
      K = a
    }, this.get_track = function () {
      return D
    }, this.reset = function (a) {
      if (!w) {
        y || this.create();
        var b = this.size;
        if (!a || ab) {
          if (ab = !1, V) {
            var c = parseInt(Math.round((parseInt(z.css("border-top-width")) + parseInt(z.css("border-bottom-width"))) / 2.5));
            b -= c
          }
          var d = v ? A[u] : b;
          if (v && 0 == d || !v && 0 == this.element.scrollWidth) return void B.removeClass("scroll-active");
          var e = v ? b : A.clientWidth;
          v || z.children(0).css(q, b), z.css(r, this.size), d > e ? (x = !0, B.css(q, e).show(), P = parseFloat((e / d).toFixed(5)), G = parseInt(Math.round(e * P)), J = parseInt(Math.round(G / 2)), I = e - G, H = parseInt(Math.round(A[t] * P)), F[q] = G + "px", F[p] = H + "px", B.addClass("scroll-active"), 0 == O && k(), L || (o.reset && (A[t] = 0, F[p] = 0), L = !0), V && l()) : (x = !1, B.hide(), B.removeClass("scroll-active"), z.css(r, ""))
        }
      }
    }, this.disable = function () {
      A[t] = 0, F[p] = 0, w = !0, x = !1, B.hide(), this.$element.addClass("scroll-disabled"), B.removeClass("scroll-active"), z.css(r, "")
    }, this.enable = function () {
      w = !1, this.$element.removeClass("scroll-disabled")
    }, this.destroy = function () {
      x = !1, w = !1, y = !1, this.$element.removeClass("ace-scroll scroll-disabled scroll-active"), this.$element.off(".ace_scroll"), V || (v || z.find("> div").children().unwrap(), z.children().unwrap(), z.remove()), B.remove(), Q !== !1 && (this.element.style.position = Q), null != db && (clearTimeout(db), db = null)
    }, this.modify = function (b) {
      b && (o = a.extend({}, o, b)), this.destroy(), this.create(), ab = !0, this.reset(!0)
    }, this.update = function (c) {
      c && (o = a.extend({}, o, c)), this.size = c.size || this.size, this.lock = c.mouseWheelLock || this.lock, this.lock_anyway = c.lockAnyway || this.lock_anyway, c.styleClass != b && (M && B.removeClass(M), M = c.styleClass, M && B.addClass(M), N = !!M.match(/scroll\-left|scroll\-top/))
    }, this.start = function () {
      A[t] = 0
    }, this.end = function () {
      A[t] = A[u]
    }, this.hide = function () {
      B.hide()
    }, this.show = function () {
      B.show()
    }, this.update_scroll = function () {
      K = !1, F[p] = H + "px", A[t] = parseInt(Math.round(H / P))
    };
    var bb = -1,
      cb = -1,
      db = null,
      eb = 0;
    return this.track_size = function () {
      return 0 == O && k(), O
    }, this.create(), ab = !0, this.reset(!0), _ = A[u], this
  };
  a.fn.ace_scroll = function (d, e) {
    var f, g = this.each(function () {
      var b = a(this),
        g = b.data("ace_scroll"),
        h = "object" == typeof d && d;
      g || b.data("ace_scroll", g = new c(this, h)), "string" == typeof d && (f = g[d](e))
    });
    return f === b ? g : f
  }, a.fn.ace_scroll.defaults = {
    size: 200,
    horizontal: !1,
    mouseWheel: !0,
    mouseWheelLock: !1,
    lockAnyway: !1,
    styleClass: !1,
    observeContent: !1,
    hideOnIdle: !1,
    hideDelay: 1500,
    hoverReset: !0,
    reset: !1,
    dragEvent: !1,
    touchDrag: !0,
    touchSwipe: !1,
    scrollEvent: !1,
    detached: !1,
    updatePos: !0
  }
}(window.jQuery),
  function (a, b) {
    var c = function (b, c) {
      var d = ace.helper.getAttrSettings(b, a.fn.ace_colorpicker.defaults),
        e = a.extend({}, a.fn.ace_colorpicker.defaults, c, d),
        f = a(b),
        g = "",
        h = "",
        i = null,
        j = [];
      f.addClass("hide").find("option").each(function () {
        var a = "colorpick-btn",
          b = this.value.replace(/[^\w\s,#\(\)\.]/g, "");
        this.value != b && (this.value = b), this.selected && (a += " selected", h = b), j.push(b), g += '<li><a class="' + a + '" href="#" style="background-color:' + b + ';" data-color="' + b + '"></a></li>'
      }).end().on("change.color", function () {
        f.next().find(".btn-colorpicker").css("background-color", this.value)
      }).after('<div class="dropdown dropdown-colorpicker">		<a data-toggle="dropdown" class="dropdown-toggle" ' + (e.auto_pos ? 'data-position="auto"' : "") + ' href="#"><span class="btn-colorpicker" style="background-color:' + h + '"></span></a><ul class="dropdown-menu' + (e.caret ? " dropdown-caret" : "") + (e.pull_right ? " dropdown-menu-right" : "") + '">' + g + "</ul></div>");
      var k = f.next().find(".dropdown-menu");
      k.on(ace.click_event, function (b) {
        var c = a(b.target);
        if (!c.is(".colorpick-btn")) return !1;
        i && i.removeClass("selected"), i = c, i.addClass("selected");
        var d = i.data("color");
        return f.val(d).trigger("change"), b.preventDefault(), !0
      }), i = f.next().find("a.selected"), this.pick = function (c, d) {
        if ("number" == typeof c) {
          if (c >= j.length) return;
          b.selectedIndex = c, k.find("a:eq(" + c + ")").trigger(ace.click_event)
        } else if ("string" == typeof c) {
          var e = c.replace(/[^\w\s,#\(\)\.]/g, "");
          if (c = j.indexOf(e), -1 == c && d === !0 && (j.push(e), a("<option />").appendTo(f).val(e), a('<li><a class="colorpick-btn" href="#"></a></li>').appendTo(k).find("a").css("background-color", e).data("color", e), c = j.length - 1), -1 == c) return;
          k.find("a:eq(" + c + ")").trigger(ace.click_event)
        }
      }, this.destroy = function () {
        f.removeClass("hide").off("change.color").next().remove(), j = []
      }
    };
    a.fn.ace_colorpicker = function (d, e) {
      var f, g = this.each(function () {
        var b = a(this),
          g = b.data("ace_colorpicker"),
          h = "object" == typeof d && d;
        g || b.data("ace_colorpicker", g = new c(this, h)), "string" == typeof d && (f = g[d](e))
      });
      return f === b ? g : f
    }, a.fn.ace_colorpicker.defaults = {
      pull_right: !1,
      caret: !0,
      auto_pos: !0
    }
  }(window.jQuery),
  function (a, b) {
    var c = "multiple" in document.createElement("INPUT"),
      d = "FileList" in window,
      e = "FileReader" in window,
      f = "File" in window,
      g = function (b, c) {
        var d = this,
          e = ace.helper.getAttrSettings(b, a.fn.ace_file_input.defaults);
        this.settings = a.extend({}, a.fn.ace_file_input.defaults, c, e), this.$element = a(b), this.element = b, this.disabled = !1, this.can_reset = !0, this.$element.off("change.ace_inner_call").on("change.ace_inner_call", function (a, b) {
          return d.disabled || b === !0 ? void 0 : i.call(d)
        });
        var f = this.$element.closest("label").css({
            display: "block"
          }),
          g = 0 == f.length ? "label" : "span";
        this.$element.wrap("<" + g + ' class="ace-file-input" />'), this.apply_settings(), this.reset_input_field()
      };
    g.error = {
      FILE_LOAD_FAILED: 1,
      IMAGE_LOAD_FAILED: 2,
      THUMBNAIL_FAILED: 3
    }, g.prototype.apply_settings = function () {
      var b = this;
      this.multi = this.$element.attr("multiple") && c, this.well_style = "well" == this.settings.style, this.well_style ? this.$element.parent().addClass("ace-file-multiple") : this.$element.parent().removeClass("ace-file-multiple"), this.$element.parent().find(":not(input[type=file])").remove(), this.$element.after('<span class="ace-file-container" data-title="' + this.settings.btn_choose + '"><span class="ace-file-name" data-title="' + this.settings.no_file + '">' + (this.settings.no_icon ? '<i class="' + ace.vars.icon + this.settings.no_icon + '"></i>' : "") + "</span></span>"), this.$label = this.$element.next(), this.$container = this.$element.closest(".ace-file-input");
      var e = !!this.settings.icon_remove;
      if (e) {
        var f = a('<a class="remove" href="#"><i class="' + ace.vars.icon + this.settings.icon_remove + '"></i></a>').appendTo(this.$element.parent());
        f.on(ace.click_event, function (a) {
          if (a.preventDefault(), !b.can_reset) return !1;
          var c = !0;
          if (b.settings.before_remove && (c = b.settings.before_remove.call(b.element)), !c) return !1;
          b.reset_input();
          return !1
        })
      }
      this.settings.droppable && d && h.call(this)
    }, g.prototype.show_file_list = function (b, c) {
      var d = "undefined" == typeof b ? this.$element.data("ace_input_files") : b;
      if (d && 0 != d.length) {
        this.well_style && (this.$label.find(".ace-file-name").remove(), this.settings.btn_change || this.$label.addClass("hide-placeholder")), this.$label.attr("data-title", this.settings.btn_change).addClass("selected");
        for (var g = 0; g < d.length; g++) {
          var h = "",
            i = !1;
          if ("string" == typeof d[g]) h = d[g];
          else if (f && d[g] instanceof File) h = a.trim(d[g].name);
          else {
            if (!(d[g] instanceof Object && d[g].hasOwnProperty("name"))) continue;
            h = d[g].name, d[g].hasOwnProperty("type") && (i = d[g].type), d[g].hasOwnProperty("path") || (d[g].path = d[g].name)
          }
          var k = h.lastIndexOf("\\") + 1;
          0 == k && (k = h.lastIndexOf("/") + 1), h = h.substr(k), 0 == i && (i = /\.(jpe?g|png|gif|svg|bmp|tiff?)$/i.test(h) ? "image" : /\.(mpe?g|flv|mov|avi|swf|mp4|mkv|webm|wmv|3gp)$/i.test(h) ? "video" : /\.(mp3|ogg|wav|wma|amr|aac)$/i.test(h) ? "audio" : "file");
          var l = {
              file: "fa fa-file",
              image: "fa fa-picture-o file-image",
              video: "fa fa-film file-video",
              audio: "fa fa-music file-audio"
            },
            m = l[i];
          if (this.well_style) {
            this.$label.append('<span class="ace-file-name" data-title="' + h + '"><i class="' + ace.vars.icon + m + '"></i></span>');
            var n = c === !0 && f && d[g] instanceof File ? a.trim(d[g].type) : "",
              o = e && this.settings.thumbnail && (n.length > 0 && n.match("image") || 0 == n.length && "image" == i);
            if (o) {
              var p = this;
              a.when(j.call(this, d[g])).fail(function (a) {
                p.settings.preview_error && p.settings.preview_error.call(p, h, a.code)
              })
            }
          } else this.$label.find(".ace-file-name").attr({
            "data-title": h
          }).find(ace.vars[".icon"]).attr("class", ace.vars.icon + m)
        }
        return !0
      }
    }, g.prototype.reset_input = function () {
      this.reset_input_ui(), this.reset_input_field()
    }, g.prototype.reset_input_ui = function () {
      this.$label.attr({
        "data-title": this.settings.btn_choose,
        "class": "ace-file-container"
      }).find(".ace-file-name:first").attr({
        "data-title": this.settings.no_file,
        "class": "ace-file-name"
      }).find(ace.vars[".icon"]).attr("class", ace.vars.icon + this.settings.no_icon).prev("img").remove(), this.settings.no_icon || this.$label.find(ace.vars[".icon"]).remove(), this.$label.find(".ace-file-name").not(":first").remove(), this.reset_input_data()
    }, g.prototype.reset_input_field = function () {
      this.$element.wrap("<form>").parent().get(0).reset(), this.$element.unwrap()
    }, g.prototype.reset_input_data = function () {
      this.$element.data("ace_input_files") && (this.$element.removeData("ace_input_files"), this.$element.removeData("ace_input_method"))
    }, g.prototype.enable_reset = function (a) {
      this.can_reset = a
    }, g.prototype.disable = function () {
      this.disabled = !0, this.$element.attr("disabled", "disabled").addClass("disabled")
    }, g.prototype.enable = function () {
      this.disabled = !1, this.$element.removeAttr("disabled").removeClass("disabled")
    }, g.prototype.files = function () {
      return a(this).data("ace_input_files") || null
    }, g.prototype.method = function () {
      return a(this).data("ace_input_method") || ""
    }, g.prototype.update_settings = function (b) {
      this.settings = a.extend({}, this.settings, b), this.apply_settings()
    }, g.prototype.loading = function (b) {
      if (b === !1) this.$container.find(".ace-file-overlay").remove(), this.element.removeAttribute("readonly");
      else {
        var c = "string" == typeof b ? b : '<i class="overlay-content fa fa-spin fa-spinner orange2 fa-2x"></i>',
          d = this.$container.find(".ace-file-overlay");
        0 == d.length && (d = a('<div class="ace-file-overlay"></div>').appendTo(this.$container), d.on("click tap", function (a) {
          return a.stopImmediatePropagation(), a.preventDefault(), !1
        }), this.element.setAttribute("readonly", "true")), d.empty().append(c)
      }
    };
    var h = function () {
        var a = this,
          b = this.$element.parent();
        b.off("dragenter").on("dragenter", function (a) {
          a.preventDefault(), a.stopPropagation()
        }).off("dragover").on("dragover", function (a) {
          a.preventDefault(), a.stopPropagation()
        }).off("drop").on("drop", function (b) {
          if (b.preventDefault(), b.stopPropagation(), !a.disabled) {
            var c = b.originalEvent.dataTransfer,
              d = c.files;
            if (!a.multi && d.length > 1) {
              var e = [];
              e.push(d[0]), d = e
            }
            return d = l.call(a, d, !0), d === !1 ? !1 : (a.$element.data("ace_input_method", "drop"), a.$element.data("ace_input_files", d), a.show_file_list(d, !0), a.$element.triggerHandler("change", [!0]), !0)
          }
        })
      },
      i = function () {
        var a = this.element.files || [this.element.value];
        return a = l.call(this, a, !1), a === !1 ? !1 : (this.$element.data("ace_input_method", "select"), this.$element.data("ace_input_files", a), this.show_file_list(a, !0), !0)
      },
      j = function (b) {
        var c = this,
          d = c.$label.find(".ace-file-name:last"),
          e = new a.Deferred,
          h = function (b) {
            d.prepend("<img class='middle' style='display:none;' />");
            var c = d.find("img:last").get(0);
            a(c).one("load", function () {
              i.call(null, c)
            }).one("error", function () {
              j.call(null, c)
            }), c.src = b
          },
          i = function (b) {
            var f = 50;
            "large" == c.settings.thumbnail ? f = 150 : "fit" == c.settings.thumbnail && (f = d.width()), d.addClass(f > 50 ? "large" : "");
            var h = k(b, f);
            if (null == h) return a(this).remove(), void e.reject({
              code: g.error.THUMBNAIL_FAILED
            });
            var i = h.w,
              j = h.h;
            "small" == c.settings.thumbnail && (i = j = f), a(b).css({
              "background-image": "url(" + h.src + ")",
              width: i,
              height: j
            }).data("thumb", h.src).attr({
              src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQImWNgYGBgAAAABQABh6FO1AAAAABJRU5ErkJggg=="
            }).show(), e.resolve()
          },
          j = function () {
            d.find("img").remove(), e.reject({
              code: g.error.IMAGE_LOAD_FAILED
            })
          };
        if (f && b instanceof File) {
          var l = new FileReader;
          l.onload = function (a) {
            h(a.target.result)
          }, l.onerror = function () {
            e.reject({
              code: g.error.FILE_LOAD_FAILED
            })
          }, l.readAsDataURL(b)
        } else b instanceof Object && b.hasOwnProperty("path") && h(b.path);
        return e.promise()
      },
      k = function (b, c) {
        var d = b.width,
          e = b.height;
        d = d > 0 ? d : a(b).width(), e = e > 0 ? e : a(b).height(), (d > c || e > c) && (d > e ? (e = parseInt(c / d * e), d = c) : (d = parseInt(c / e * d), e = c));
        var f;
        try {
          var g = document.createElement("canvas");
          g.width = d, g.height = e;
          var h = g.getContext("2d");
          h.drawImage(b, 0, 0, b.width, b.height, 0, 0, d, e), f = g.toDataURL()
        } catch (i) {
          f = null
        }
        return f ? (/^data\:image\/(png|jpe?g|gif);base64,[0-9A-Za-z\+\/\=]+$/.test(f) || (f = null), f ? {
          src: f,
          w: d,
          h: e
        } : null) : null
      },
      l = function (a, b) {
        var c = o.call(this, a, b);
        return -1 === c ? (this.reset_input(), !1) : c && 0 != c.length ? ((c instanceof Array || d && c instanceof FileList) && (a = c), c = !0, this.settings.before_change && (c = this.settings.before_change.call(this.element, a, b)), -1 === c ? (this.reset_input(), !1) : c && 0 != c.length ? ((c instanceof Array || d && c instanceof FileList) && (a = c), a) : (this.$element.data("ace_input_files") || this.reset_input(), !1)) : (this.$element.data("ace_input_files") || this.reset_input(), !1)
      },
      m = function (a) {
        return a ? ("string" == typeof a && (a = [a]), 0 == a.length ? null : new RegExp(".(?:" + a.join("|") + ")$", "i")) : null
      },
      n = function (a) {
        return a ? ("string" == typeof a && (a = [a]), 0 == a.length ? null : new RegExp("^(?:" + a.join("|").replace(/\//g, "\\/") + ")$", "i")) : null
      },
      o = function (b, c) {
        var d = m(this.settings.allowExt),
          e = m(this.settings.denyExt),
          g = n(this.settings.allowMime),
          h = n(this.settings.denyMime),
          i = this.settings.maxSize || !1;
        if (!(d || e || g || h || i)) return !0;
        for (var j = [], k = {}, l = 0; l < b.length; l++) {
          var o = b[l],
            p = f ? o.name : o;
          if (!d || d.test(p))
            if (e && e.test(p)) "ext" in k || (k.ext = []), k.ext.push(p);
            else {
              var q;
              if (f) {
                if ((q = a.trim(o.type)).length > 0) {
                  if (g && !g.test(q)) {
                    "mime" in k || (k.mime = []), k.mime.push(p);
                    continue
                  }
                  if (h && h.test(q)) {
                    "mime" in k || (k.mime = []), k.mime.push(p);
                    continue
                  }
                }
                i && o.size > i ? ("size" in k || (k.size = []), k.size.push(p)) : j.push(o)
              } else j.push(o)
            } else "ext" in k || (k.ext = []), k.ext.push(p)
        }
        if (j.length == b.length) return b;
        var r = {
          ext: 0,
          mime: 0,
          size: 0
        };
        "ext" in k && (r.ext = k.ext.length), "mime" in k && (r.mime = k.mime.length), "size" in k && (r.size = k.size.length);
        var s;
        return this.$element.trigger(s = new a.Event("file.error.ace"), {
          file_count: b.length,
          invalid_count: b.length - j.length,
          error_list: k,
          error_count: r,
          dropped: c
        }), s.isDefaultPrevented() ? -1 : j
      };
    a.fn.aceFileInput = a.fn.ace_file_input = function (c, d) {
      var e, f = this.each(function () {
        var b = a(this),
          f = b.data("ace_file_input"),
          h = "object" == typeof c && c;
        f || b.data("ace_file_input", f = new g(this, h)), "string" == typeof c && (e = f[c](d))
      });
      return e === b ? f : e
    }, a.fn.ace_file_input.defaults = {
      style: !1,
      no_file: "No File ...",
      no_icon: "fa fa-upload",
      btn_choose: "Choose",
      btn_change: "Change",
      icon_remove: "fa fa-times",
      droppable: !1,
      thumbnail: !1,
      allowExt: null,
      denyExt: null,
      allowMime: null,
      denyMime: null,
      maxSize: !1,
      before_change: null,
      before_remove: null,
      preview_error: null
    }
  }(window.jQuery), ! function (a) {
  "use strict";
  var b = function (b, c) {
    this.$element = a(b), this.options = a.extend({}, a.fn.bs_typeahead.defaults, c), this.matcher = this.options.matcher || this.matcher, this.sorter = this.options.sorter || this.sorter, this.highlighter = this.options.highlighter || this.highlighter, this.updater = this.options.updater || this.updater, this.source = this.options.source, this.$menu = a(this.options.menu), this.shown = !1, this.listen()
  };
  b.prototype = {
    constructor: b,
    select: function () {
      var a = this.$menu.find(".active").attr("data-value");
      return this.$element.val(this.updater(a)).change(), this.hide()
    },
    updater: function (a) {
      return a
    },
    show: function () {
      var b = a.extend({}, this.$element.position(), {
        height: this.$element[0].offsetHeight
      });
      return this.$menu.insertAfter(this.$element).css({
        top: b.top + b.height,
        left: b.left
      }).show(), this.shown = !0, this
    },
    hide: function () {
      return this.$menu.hide(), this.shown = !1, this
    },
    lookup: function () {
      var b;
      return this.query = this.$element.val(), !this.query || this.query.length < this.options.minLength ? this.shown ? this.hide() : this : (b = a.isFunction(this.source) ? this.source(this.query, a.proxy(this.process, this)) : this.source, b ? this.process(b) : this)
    },
    process: function (b) {
      var c = this;
      return b = a.grep(b, function (a) {
        return c.matcher(a)
      }), b = this.sorter(b), b.length ? this.render(b.slice(0, this.options.items)).show() : this.shown ? this.hide() : this
    },
    matcher: function (a) {
      return ~a.toLowerCase().indexOf(this.query.toLowerCase())
    },
    sorter: function (a) {
      for (var b, c = [], d = [], e = []; b = a.shift();) b.toLowerCase().indexOf(this.query.toLowerCase()) ? ~b.indexOf(this.query) ? d.push(b) : e.push(b) : c.push(b);
      return c.concat(d, e)
    },
    highlighter: function (a) {
      var b = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
      return a.replace(new RegExp("(" + b + ")", "ig"), function (a, b) {
        return "<strong>" + b + "</strong>"
      })
    },
    render: function (b) {
      var c = this;
      return b = a(b).map(function (b, d) {
        return b = a(c.options.item).attr("data-value", d), b.find("a").html(c.highlighter(d)), b[0]
      }), b.first().addClass("active"), this.$menu.html(b), this
    },
    next: function () {
      var b = this.$menu.find(".active").removeClass("active"),
        c = b.next();
      c.length || (c = a(this.$menu.find("li")[0])), c.addClass("active")
    },
    prev: function () {
      var a = this.$menu.find(".active").removeClass("active"),
        b = a.prev();
      b.length || (b = this.$menu.find("li").last()), b.addClass("active")
    },
    listen: function () {
      this.$element.on("focus", a.proxy(this.focus, this)).on("blur", a.proxy(this.blur, this)).on("keypress", a.proxy(this.keypress, this)).on("keyup", a.proxy(this.keyup, this)), this.eventSupported("keydown") && this.$element.on("keydown", a.proxy(this.keydown, this)), this.$menu.on("click", a.proxy(this.click, this)).on("mouseenter", "li", a.proxy(this.mouseenter, this)).on("mouseleave", "li", a.proxy(this.mouseleave, this))
    },
    eventSupported: function (a) {
      var b = a in this.$element;
      return b || (this.$element.setAttribute(a, "return;"), b = "function" == typeof this.$element[a]), b
    },
    move: function (a) {
      if (this.shown) {
        switch (a.keyCode) {
          case 9:
          case 13:
          case 27:
            a.preventDefault();
            break;
          case 38:
            a.preventDefault(), this.prev();
            break;
          case 40:
            a.preventDefault(), this.next()
        }
        a.stopPropagation()
      }
    },
    keydown: function (b) {
      this.suppressKeyPressRepeat = ~a.inArray(b.keyCode, [40, 38, 9, 13, 27]), this.move(b)
    },
    keypress: function (a) {
      this.suppressKeyPressRepeat || this.move(a)
    },
    keyup: function (a) {
      switch (a.keyCode) {
        case 40:
        case 38:
        case 16:
        case 17:
        case 18:
          break;
        case 9:
        case 13:
          if (!this.shown) return;
          this.select();
          break;
        case 27:
          if (!this.shown) return;
          this.hide();
          break;
        default:
          this.lookup()
      }
      a.stopPropagation(), a.preventDefault()
    },
    focus: function () {
      this.focused = !0
    },
    blur: function () {
      this.focused = !1, !this.mousedover && this.shown && this.hide()
    },
    click: function (a) {
      a.stopPropagation(), a.preventDefault(), this.select(), this.$element.focus()
    },
    mouseenter: function (b) {
      this.mousedover = !0, this.$menu.find(".active").removeClass("active"), a(b.currentTarget).addClass("active")
    },
    mouseleave: function () {
      this.mousedover = !1, !this.focused && this.shown && this.hide()
    }
  };
  var c = a.fn.bs_typeahead;
  a.fn.bs_typeahead = function (c) {
    return this.each(function () {
      var d = a(this),
        e = d.data("bs_typeahead"),
        f = "object" == typeof c && c;
      e || d.data("bs_typeahead", e = new b(this, f)), "string" == typeof c && e[c]()
    })
  }, a.fn.bs_typeahead.defaults = {
    source: [],
    items: 8,
    menu: '<ul class="typeahead dropdown-menu"></ul>',
    item: '<li><a href="#"></a></li>',
    minLength: 1
  }, a.fn.bs_typeahead.Constructor = b, a.fn.bs_typeahead.noConflict = function () {
    return a.fn.bs_typeahead = c, this
  }, a(document).on("focus.bs_typeahead.data-api", '[data-provide="bs_typeahead"]', function () {
    var b = a(this);
    b.data("bs_typeahead") || b.bs_typeahead(b.data())
  })
}(window.jQuery),
  function (a) {
    a.fn.ace_wysiwyg = function (b) {
      var c = a.extend({
          speech_button: !0,
          wysiwyg: {}
        }, b),
        d = ["#ac725e", "#d06b64", "#f83a22", "#fa573c", "#ff7537", "#ffad46", "#42d692", "#16a765", "#7bd148", "#b3dc6c", "#fbe983", "#fad165", "#92e1c0", "#9fe1e7", "#9fc6e7", "#4986e7", "#9a9cff", "#b99aff", "#c2c2c2", "#cabdbf", "#cca6ac", "#f691b2", "#cd74e6", "#a47ae2", "#444444"],
        e = {
          font: {
            values: ["Arial", "Courier", "Comic Sans MS", "Helvetica", "Open Sans", "Tahoma", "Verdana"],
            icon: "fa fa-font",
            title: "Font"
          },
          fontSize: {
            values: {
              5: "Huge",
              3: "Normal",
              1: "Small"
            },
            icon: "fa fa-text-height",
            title: "Font Size"
          },
          bold: {
            icon: "fa fa-bold",
            title: "Bold (Ctrl/Cmd+B)"
          },
          italic: {
            icon: "fa fa-italic",
            title: "Italic (Ctrl/Cmd+I)"
          },
          strikethrough: {
            icon: "fa fa-strikethrough",
            title: "Strikethrough"
          },
          underline: {
            icon: "fa fa-underline",
            title: "Underline"
          },
          insertunorderedlist: {
            icon: "fa fa-list-ul",
            title: "Bullet list"
          },
          insertorderedlist: {
            icon: "fa fa-list-ol",
            title: "Number list"
          },
          outdent: {
            icon: "fa fa-outdent",
            title: "Reduce indent (Shift+Tab)"
          },
          indent: {
            icon: "fa fa-indent",
            title: "Indent (Tab)"
          },
          justifyleft: {
            icon: "fa fa-align-left",
            title: "Align Left (Ctrl/Cmd+L)"
          },
          justifycenter: {
            icon: "fa fa-align-center",
            title: "Center (Ctrl/Cmd+E)"
          },
          justifyright: {
            icon: "fa fa-align-right",
            title: "Align Right (Ctrl/Cmd+R)"
          },
          justifyfull: {
            icon: "fa fa-align-justify",
            title: "Justify (Ctrl/Cmd+J)"
          },
          createLink: {
            icon: "fa fa-link",
            title: "Hyperlink",
            button_text: "Add",
            placeholder: "URL",
            button_class: "btn-primary"
          },
          unlink: {
            icon: "fa fa-chain-broken",
            title: "Remove Hyperlink"
          },
          insertImage: {
            icon: "fa fa-picture-o",
            title: "Insert picture",
            button_text: '<i class="' + ace.vars.icon + 'fa fa-file"></i> Choose Image &hellip;',
            placeholder: "Image URL",
            button_insert: "Insert",
            button_class: "btn-success",
            button_insert_class: "btn-primary",
            choose_file: !0
          },
          foreColor: {
            values: d,
            title: "Change Color"
          },
          backColor: {
            values: d,
            title: "Change Background Color"
          },
          undo: {
            icon: "fa fa-undo",
            title: "Undo (Ctrl/Cmd+Z)"
          },
          redo: {
            icon: "fa fa-repeat",
            title: "Redo (Ctrl/Cmd+Y)"
          },
          viewSource: {
            icon: "fa fa-code",
            title: "View Source"
          }
        },
        f = c.toolbar || ["font", null, "fontSize", null, "bold", "italic", "strikethrough", "underline", null, "insertunorderedlist", "insertorderedlist", "outdent", "indent", null, "justifyleft", "justifycenter", "justifyright", "justifyfull", null, "createLink", "unlink", null, "insertImage", null, "foreColor", null, "undo", "redo", null, "viewSource"];
      return this.each(function () {
        var b = ' <div class="wysiwyg-toolbar btn-toolbar center"> <div class="btn-group"> ';
        for (var d in f)
          if (f.hasOwnProperty(d)) {
            var g = f[d];
            if (null === g) {
              b += ' </div> <div class="btn-group"> ';
              continue
            }
            if ("string" == typeof g && g in e) g = e[g], g.name = f[d];
            else {
              if (!("object" == typeof g && g.name in e)) continue;
              g = a.extend(e[g.name], g)
            }
            var h = "className" in g ? g.className : "btn-default";
            switch (g.name) {
              case "font":
                b += ' <a class="btn btn-sm ' + h + ' dropdown-toggle" data-toggle="dropdown" title="' + g.title + '"><i class="' + ace.vars.icon + g.icon + '"></i><i class="' + ace.vars.icon + 'fa fa-angle-down icon-on-right"></i></a> ', b += ' <ul class="dropdown-menu dropdown-light dropdown-caret">';
                for (var i in g.values) g.values.hasOwnProperty(i) && (b += ' <li><a data-edit="fontName ' + g.values[i] + '" style="font-family:\'' + g.values[i] + "'\">" + g.values[i] + "</a></li> ");
                b += " </ul>";
                break;
              case "fontSize":
                b += ' <a class="btn btn-sm ' + h + ' dropdown-toggle" data-toggle="dropdown" title="' + g.title + '"><i class="' + ace.vars.icon + g.icon + '"></i>&nbsp;<i class="' + ace.vars.icon + 'fa fa-angle-down icon-on-right"></i></a> ', b += ' <ul class="dropdown-menu dropdown-light dropdown-caret"> ';
                for (var j in g.values) g.values.hasOwnProperty(j) && (b += ' <li><a data-edit="fontSize ' + j + '"><font size="' + j + '">' + g.values[j] + "</font></a></li> ");
                b += " </ul> ";
                break;
              case "createLink":
                b += ' <div class="btn-group"> <a class="btn btn-sm ' + h + ' dropdown-toggle" data-toggle="dropdown" title="' + g.title + '"><i class="' + ace.vars.icon + g.icon + '"></i></a> ', b += ' <div class="dropdown-menu dropdown-caret dropdown-menu-right">							 <div class="input-group">								<input class="form-control" placeholder="' + g.placeholder + '" type="text" data-edit="' + g.name + '" />								<span class="input-group-btn">									<button class="btn btn-sm ' + g.button_class + '" type="button">' + g.button_text + "</button>								</span>							 </div>						</div> </div>";
                break;
              case "insertImage":
                b += ' <div class="btn-group"> <a class="btn btn-sm ' + h + ' dropdown-toggle" data-toggle="dropdown" title="' + g.title + '"><i class="' + ace.vars.icon + g.icon + '"></i></a> ', b += ' <div class="dropdown-menu dropdown-caret dropdown-menu-right">							 <div class="input-group">								<input class="form-control" placeholder="' + g.placeholder + '" type="text" data-edit="' + g.name + '" />								<span class="input-group-btn">									<button class="btn btn-sm ' + g.button_insert_class + '" type="button">' + g.button_insert + "</button>								</span>							 </div>", g.choose_file && "FileReader" in window && (b += '<div class="space-2"></div>							 <label class="center block no-margin-bottom">								<button class="btn btn-sm ' + g.button_class + ' wysiwyg-choose-file" type="button">' + g.button_text + '</button>								<input type="file" data-edit="' + g.name + '" />							  </label>'), b += " </div> </div>";
                break;
              case "foreColor":
              case "backColor":
                b += ' <select class="hide wysiwyg_colorpicker" title="' + g.title + '"> ', a.each(g.values, function (a, c) {
                  b += ' <option value="' + c + '">' + c + "</option> "
                }), b += " </select> ", b += ' <input style="display:none;" disabled class="hide" type="text" data-edit="' + g.name + '" /> ';
                break;
              case "viewSource":
                b += ' <a class="btn btn-sm ' + h + '" data-view="source" title="' + g.title + '"><i class="' + ace.vars.icon + g.icon + '"></i></a> ';
                break;
              default:
                b += ' <a class="btn btn-sm ' + h + '" data-edit="' + g.name + '" title="' + g.title + '"><i class="' + ace.vars.icon + g.icon + '"></i></a> '
            }
          }
        b += " </div> ";
        var k;
        c.speech_button && "onwebkitspeechchange" in (k = document.createElement("input")) && (b += ' <input class="wysiwyg-speech-input" type="text" data-edit="inserttext" x-webkit-speech />'), k = null, b += " </div> ", b = c.toolbar_place ? c.toolbar_place.call(this, b) : a(this).before(b).prev(), b.find("a[title]").tooltip({
          animation: !1,
          container: "body"
        }), b.find(".dropdown-menu input[type=text]").on("click", function () {
          return !1
        }).on("change", function () {
          a(this).closest(".dropdown-menu").siblings(".dropdown-toggle").dropdown("toggle")
        }).on("keydown", function (b) {
          27 == b.which ? (this.value = "", a(this).change()) : 13 == b.which && (b.preventDefault(), b.stopPropagation(), a(this).change())
        }), b.find("input[type=file]").prev().on(ace.click_event, function () {
          a(this).next().click()
        }), b.find(".wysiwyg_colorpicker").each(function () {
          a(this).ace_colorpicker({
            pull_right: !0
          }).change(function () {
            a(this).nextAll("input").eq(0).val(this.value).change()
          }).next().find(".btn-colorpicker").tooltip({
            title: this.title,
            animation: !1,
            container: "body"
          })
        });
        var l = a(this),
          m = !1;
        b.find("a[data-view=source]").on("click", function (b) {
          if (b.preventDefault(), m) {
            var c = l.next();
            l.html(c.val()).show(), c.remove(), a(this).removeClass("active")
          } else a("<textarea />").css({
            width: l.outerWidth(),
            height: l.outerHeight()
          }).val(l.html()).insertAfter(l), l.hide(), a(this).addClass("active");
          m = !m
        });
        var n = a.extend({}, {
          activeToolbarClass: "active",
          toolbarSelector: b
        }, c.wysiwyg || {});
        a(this).wysiwyg(n)
      }), this
    }
  }(window.jQuery),
  function (a, b) {
    function c(b, c) {
      var d = ace.helper.getAttrSettings(b, a.fn.ace_spinner.defaults),
        e = a.extend({}, a.fn.ace_spinner.defaults, c, d),
        f = e.max;
      f = ("" + f).length;
      var g = parseInt(Math.max(20 * f + 40, 90)),
        h = a(b),
        i = "btn-sm",
        j = 2;
      h.hasClass("input-sm") ? (i = "btn-xs", j = 1) : h.hasClass("input-lg") && (i = "btn-lg", j = 3), 2 == j ? g += 25 : 3 == j && (g += 50), h.addClass("spinbox-input form-control text-center").wrap('<div class="ace-spinner middle">');
      var k = h.closest(".ace-spinner").spinbox(e).wrapInner("<div class='input-group'></div>"),
        l = k.data("fu.spinbox");
      e.on_sides ? (h.before('<div class="spinbox-buttons input-group-btn">					<button type="button" class="btn spinbox-down ' + i + " " + e.btn_down_class + '">						<i class="icon-only ' + ace.vars.icon + e.icon_down + '"></i>					</button>				</div>').after('<div class="spinbox-buttons input-group-btn">					<button type="button" class="btn spinbox-up ' + i + " " + e.btn_up_class + '">						<i class="icon-only ' + ace.vars.icon + e.icon_up + '"></i>					</button>				</div>'), k.addClass("touch-spinner"), k.css("width", g + "px")) : (h.after('<div class="spinbox-buttons input-group-btn">					<button type="button" class="btn spinbox-up ' + i + " " + e.btn_up_class + '">						<i class="icon-only ' + ace.vars.icon + e.icon_up + '"></i>					</button>					<button type="button" class="btn spinbox-down ' + i + " " + e.btn_down_class + '">						<i class="icon-only ' + ace.vars.icon + e.icon_down + '"></i>					</button>				</div>'), ace.vars.touch || e.touch_spinner ? (k.addClass("touch-spinner"), k.css("width", g + "px")) : (h.next().addClass("btn-group-vertical"), k.css("width", g + "px"))), k.on("changed", function () {
        h.trigger("change")
      }), this._call = function (a, b) {
        l[a](b)
      }
    }
    a.fn.ace_spinner = function (d, e) {
      var f, g = this.each(function () {
        var b = a(this),
          g = b.data("ace_spinner"),
          h = "object" == typeof d && d;
        g || (h = a.extend({}, a.fn.ace_spinner.defaults, d), b.data("ace_spinner", g = new c(this, h))), "string" == typeof d && (f = g._call(d, e))
      });
      return f === b ? g : f
    }, a.fn.ace_spinner.defaults = {
      icon_up: "fa fa-chevron-up",
      icon_down: "fa fa-chevron-down",
      on_sides: !1,
      btn_up_class: "",
      btn_down_class: "",
      max: 999,
      touch_spinner: !1
    }
  }(window.jQuery),
  function (a) {
    a.fn.aceTree = a.fn.ace_tree = function (b) {
      var c = {
        "open-icon": ace.vars.icon + "fa fa-folder-open",
        "close-icon": ace.vars.icon + "fa fa-folder",
        selectable: !0,
        "selected-icon": ace.vars.icon + "fa fa-check",
        "unselected-icon": ace.vars.icon + "fa fa-times",
        loadingHTML: "Loading..."
      };
      return this.each(function () {
        var d = ace.helper.getAttrSettings(this, c),
          e = a.extend({}, c, b, d),
          f = a(this);
        f.addClass("tree").attr("role", "tree"), f.html('<li class="tree-branch hide" data-template="treebranch" role="treeitem" aria-expanded="false">				<div class="tree-branch-header">					<span class="tree-branch-name">						<i class="icon-folder ' + e["close-icon"] + '"></i>						<span class="tree-label"></span>					</span>				</div>				<ul class="tree-branch-children" role="group"></ul>				<div class="tree-loader" role="alert">' + e.loadingHTML + '</div>			</div>			<li class="tree-item hide" data-template="treeitem" role="treeitem">				<span class="tree-item-name">				  ' + (null == e["unselected-icon"] ? "" : '<i class="icon-item ' + e["unselected-icon"] + '"></i>') + '				  <span class="tree-label"></span>				</span>			</li>'), f.addClass(1 == e.selectable ? "tree-selectable" : "tree-unselectable"), f.tree(e)
      }), this
    }
  }(window.jQuery),
  function (a) {
    a.fn.aceWizard = a.fn.ace_wizard = function (b) {
      return this.each(function () {
        var c = a(this);
        c.wizard(), ace.vars.old_ie && c.find("ul.steps > li").last().addClass("last-child");
        var d = b && b.buttons ? a(b.buttons) : c.siblings(".wizard-actions").eq(0),
          e = c.data("fu.wizard");
        e.$prevBtn.remove(), e.$nextBtn.remove(), e.$prevBtn = d.find(".btn-prev").eq(0).on(ace.click_event, function () {
          e.previous()
        }).attr("disabled", "disabled"), e.$nextBtn = d.find(".btn-next").eq(0).on(ace.click_event, function () {
          e.next()
        }).removeAttr("disabled"), e.nextText = e.$nextBtn.text();
        var f = b && (b.selectedItem && b.selectedItem.step || b.step);
        f && (e.currentStep = f, e.setState())
      }), this
    }
  }(window.jQuery),
  function (a, b) {
    function c(b, c) {
      var e = this,
        f = a(b),
        g = "right",
        h = !1,
        i = f.hasClass("fade"),
        j = ace.helper.getAttrSettings(b, a.fn.ace_aside.defaults);
      if (this.settings = a.extend({}, a.fn.ace_aside.defaults, c, j), !this.settings.background || c.scroll_style || j.scroll_style || (this.settings.scroll_style = "scroll-white no-track"), this.container = this.settings.container, this.container) try {
        a(this.container).get(0) == document.body && (this.container = null)
      } catch (k) {}
      this.container && (this.settings.backdrop = !1, f.addClass("aside-contained"));
      var l = f.find(".modal-dialog"),
        m = f.find(".modal-content"),
        n = 300;
      this.initiate = function () {
        b.className = b.className.replace(/(\s|^)aside\-(right|top|left|bottom)(\s|$)/gi, "$1$3"), g = this.settings.placement, g && (g = a.trim(g.toLowerCase())), g && /right|top|left|bottom/.test(g) || (g = "right"), f.attr("data-placement", g), f.addClass("aside-" + g), /right|left/.test(g) ? (h = !0, f.addClass("aside-vc")) : f.addClass("aside-hz"), this.settings.fixed && f.addClass("aside-fixed"), this.settings.background && f.addClass("aside-dark"), this.settings.offset && f.addClass("navbar-offset"), this.settings.transition || f.addClass("transition-off"), f.addClass("aside-hidden"), this.insideContainer(), l = f.find(".modal-dialog"), m = f.find(".modal-content"), this.settings.body_scroll || f.on("mousewheel.aside DOMMouseScroll.aside touchmove.aside pointermove.aside", function (b) {
          return a.contains(m[0], b.target) ? void 0 : (b.preventDefault(), !1)
        }), 0 == this.settings.backdrop && f.addClass("no-backdrop")
      }, this.show = function () {
        if (0 == this.settings.backdrop) try {
          f.data("bs.modal").$backdrop.remove()
        } catch (b) {}
        this.container ? a(this.container).addClass("overflow-hidden") : f.css("position", "fixed"), f.removeClass("aside-hidden")
      }, this.hide = function () {
        this.container && (this.container.addClass("overflow-hidden"), ace.vars.firefox && b.offsetHeight), o(), ace.vars.transition && !i && f.one("bsTransitionEnd", function () {
          f.addClass("aside-hidden"), f.css("position", ""), e.container && e.container.removeClass("overflow-hidden")
        }).emulateTransitionEnd(n)
      }, this.shown = function () {
        if (o(), a("body").removeClass("modal-open").css("padding-right", ""), "invisible" == this.settings.backdrop) try {
          f.data("bs.modal").$backdrop.css("opacity", 0)
        } catch (b) {}
        var c = h ? m.height() : l.height();
        ace.vars.touch ? m.addClass("overflow-scroll").css("max-height", c + "px") : m.hasClass("ace-scroll") || m.ace_scroll({
          size: c,
          reset: !0,
          mouseWheelLock: !0,
          lockAnyway: !this.settings.body_scroll,
          styleClass: this.settings.scroll_style,
          observeContent: !0,
          hideOnIdle: !ace.vars.old_ie,
          hideDelay: 1500
        }), d.off("resize.modal.aside").on("resize.modal.aside", function () {
          if (ace.vars.touch) m.css("max-height", (h ? m.height() : l.height()) + "px");
          else {
            m.ace_scroll("disable");
            var a = h ? m.height() : l.height();
            m.ace_scroll("update", {
              size: a
            }).ace_scroll("enable").ace_scroll("reset")
          }
        }).triggerHandler("resize.modal.aside"), e.container && ace.vars.transition && !i && f.one("bsTransitionEnd", function () {
          e.container.removeClass("overflow-hidden")
        }).emulateTransitionEnd(n)
      }, this.hidden = function () {
        d.off(".aside"), (!ace.vars.transition || i) && (f.addClass("aside-hidden"), f.css("position", ""))
      }, this.insideContainer = function () {
        var b = a(".main-container"),
          c = f.find(".modal-dialog");
        if (c.css({
            right: "",
            left: ""
          }), b.hasClass("container")) {
          var e = !1;
          1 == h && (c.css(g, parseInt((d.width() - b.width()) / 2)), e = !0), e && ace.vars.firefox && ace.helper.redraw(b[0])
        }
      }, this.flip = function () {
        var a = {
          right: "left",
          left: "right",
          top: "bottom",
          bottom: "top"
        };
        f.removeClass("aside-" + g).addClass("aside-" + a[g]), g = a[g]
      };
      var o = function () {
        var a = f.find(".aside-trigger");
        if (0 != a.length) {
          a.toggleClass("open");
          var b = a.find(ace.vars[".icon"]);
          0 != b.length && b.toggleClass(b.attr("data-icon1") + " " + b.attr("data-icon2"))
        }
      };
      this.initiate(), this.container && (this.container = a(this.container)), f.appendTo(this.container || "body")
    }
    var d = a(window);
    a(document).on("show.bs.modal", ".modal.aside", function () {
      a(".aside.in").modal("hide"), a(this).ace_aside("show")
    }).on("hide.bs.modal", ".modal.aside", function () {
      a(this).ace_aside("hide")
    }).on("shown.bs.modal", ".modal.aside", function () {
      a(this).ace_aside("shown")
    }).on("hidden.bs.modal", ".modal.aside", function () {
      a(this).ace_aside("hidden")
    }), a(window).on("resize.aside_container", function () {
      a(".modal.aside").ace_aside("insideContainer")
    }), a(document).on("settings.ace.aside", function (b, c) {
      "main_container_fixed" == c && a(".modal.aside").ace_aside("insideContainer")
    }), a.fn.aceAside = a.fn.ace_aside = function (d, e) {
      var f, g = this.each(function () {
        var b = a(this),
          g = b.data("ace_aside"),
          h = "object" == typeof d && d;
        g || b.data("ace_aside", g = new c(this, h)), "string" == typeof d && "function" == typeof g[d] && (f = e instanceof Array ? g[d].apply(g, e) : g[d](e))
      });
      return f === b ? g : f
    }, a.fn.ace_aside.defaults = {
      fixed: !1,
      background: !1,
      offset: !1,
      body_scroll: !1,
      transition: !0,
      scroll_style: "scroll-dark no-track",
      container: null,
      backdrop: !1,
      placement: "right"
    }
  }(window.jQuery);