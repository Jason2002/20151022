/**
 * Created by jh3r on 12/30/2014.
 */


require('coffee-script/register');
require('./gulpfile.coffee');

