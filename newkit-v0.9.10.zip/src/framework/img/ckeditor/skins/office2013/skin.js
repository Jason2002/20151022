﻿/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.skin.name="office2013";CKEDITOR.skin.ua_editor="";CKEDITOR.skin.ua_dialog="";CKEDITOR.skin.chameleon=function(){return""};